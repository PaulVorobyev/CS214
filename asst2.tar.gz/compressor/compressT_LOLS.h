#ifndef __COMPRESST_LOLS
#define __COMPRESST_LOLS

void compressT_LOLS(char*,int);

#endif
