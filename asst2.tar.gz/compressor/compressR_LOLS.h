#ifndef __COMPRESSR_LOLS
#define __COMPRESSR_LOLS

void compressR_LOLS(char*,int);

#endif
