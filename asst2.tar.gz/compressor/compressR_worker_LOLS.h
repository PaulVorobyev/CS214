#include "parts_compressor.h"
#ifndef __COMPRESS_WORKER
#define __COMPRESS_WORKER

void compressor_worker(metadata*);

#endif
