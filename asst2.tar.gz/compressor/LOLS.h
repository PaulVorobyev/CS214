#ifndef _LOLS_H
#define _LOLS_H

int power(int, int);
char* int_to_str(int);
void compressor(char*);

#endif // _LOLS_H
